public class Hanshu {
    public static void main(String[] args) {
        double s0 = 0.000290888;
        double c0 = Math.pow((1 - Math.pow(s0,2)),0.5);
        System.out.println("sin1="+s0);
        double s = s0;
        double c = c0;
        for (int n = 2;n<=90;n++){
            s = s * c0 + c * s0;
            c = Math.pow((1 - Math.pow(s,2)),0.5);
            System.out.println(s);
            n = n + 1;
            if (n>5400){
                break;
            } else continue;
        }
    }
}
